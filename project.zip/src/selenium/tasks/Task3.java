package selenium.tasks;

import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.Assert.assertEquals;

public class Task3 {
    WebDriver driver;

    @Before
    public void openPage() {
        String libWithDriversLocation =  System.getProperty("user.dir") + "\\lib\\";
        System.setProperty("webdriver.chrome.driver", libWithDriversLocation + "chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://kristinek.github.io/test-sample/tasks/task4");
    }

    @After
    public void closeBrowser(){
        driver.quit();
    }

    @Test
    public void feedback() {
        String name = "Maksims";
        String age = "30";
        String like = "Good";
        driver.findElement(By.id("fb_name")).sendKeys(name);
        String newTextOne = "sending some keys";



//        fill in "name", "age", select 1 or more language, select genre, select option, add a comment
        driver.findElement(By.id("fb_name")).sendKeys(name);
        driver.findElement(By.id("fb_age")).sendKeys(age);
        driver.findElement(By.cssSelector("input[value='lang_eng']")).click();
        driver.findElement(By.cssSelector("input[value='gen_male']")).click();
        //Select dropdown = new Select(driver.findElement(By.id("like_us")));
        //dropdown.selectOptionByText(like);

        //textArea.sendKeys(commment);

//        check that the button send is blue with white letters
        WebElement sendButton = driver.findElement(By.xpath("//div[h1]"));
        assertEquals("rgba(241, 241, 241, 1)", sendButton.getCssValue("background-color") ); //blue color
        assertEquals("rgb(33, 150, 243)", sendButton.getCssValue("text-decoration-color")); //white color
//        click "send"
        sendButton.click();
//        check that the feedback was filled correctly
        assertEquals("Is this the freedback you want to give us?",driver.findElement(By.cssSelector(".w3-card-4> .w3-light-grey")).getText());


        assertEquals("Your name:" + name,driver.findElement(By.cssSelector(".w3-card-4> .w3-container p:nth-of-type(1)")).getText());
        assertEquals("Your age:" + age,driver.findElement(By.cssSelector(".w3-card-4> .w3-container p:nth-of-type(2)")).getText());
        assertEquals("Your language:" + "English",driver.findElement(By.cssSelector(".w3-card-4> .w3-container p:nth-of-type(3)")).getText());
        assertEquals("Your genre:" + "Male",driver.findElement(By.cssSelector(".w3-card-4> .w3-container p:nth-of-type(4)")).getText());
        assertEquals("Your option of us:" + like,driver.findElement(By.cssSelector(".w3-card-4> .w3-container p:nth-of-type(5)")).getText());
        assertEquals("Your comment:" + "Hello to everybody!",driver.findElement(By.cssSelector(".w3-card-4> .w3-container p:nth-of-type(6)")).getText());

//        check that the button yes is green and no is red but both have white letters
        WebElement greenButton = driver.findElement(By.cssSelector("button.w3-green"));
        assertEquals("rgba(76, 175, 80, 1)",greenButton.getCssValue("background-color")); // green color of YES button
        assertEquals("rgb(255, 255, 255)", greenButton.getCssValue("text-decoration-color")); //white color of YES button

        WebElement redButton = driver.findElement(By.cssSelector("button.w3-red"));
        assertEquals("rgba(244, 67, 54, 1)",redButton.getCssValue("background-color")); // red color of NO button
        assertEquals("rgb(255, 255, 255)", redButton.getCssValue("text-decoration-color")); //white color of NO button




    }
}
